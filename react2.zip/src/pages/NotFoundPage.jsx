import React from "react";

function NotFoundPage() {
  return (
    <section className="not-found">
      <h1>404 Not Found</h1>
    </section>
  );
}

export default NotFoundPage;
